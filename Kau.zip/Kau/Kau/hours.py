Hours = {

    "computer": 3,

    "math": 3,
    "prog1": 3,
    "prog2": 3,

    "english": 3,
    "CPIT1": 3,
    "CPIT2": 2,


}
