#ohood alharbi CS 26-12-1441

from hours import *
#import dictonary

while True:
    # I'll do while loop to put on it the list of services in this program :
    print('''


قائمة الخدمات المتوفرة للاستفسارعن                                      
شروط تحويل الطلاب والطالبات من الكليات الأخرى في جامعة الملك عبد العزيز إلى كلية الحاسبات وتقنية المعلومات   
                             =====================================================
ادخل معلوماتك اذا اردت التحقق من إمكانية قبولك <1>                             
                             اذا اردت مشاهدة الشروط القبول في الكلية <2>
                             اذا اردت حساب المعدل الموزون في المواد<3>
                             خروج <4>
                             ====================================================

      ادخل رقم العملية التي تود تنفيذها :                          


''')  # I print the list of services  and ask for enter the number if services

    Enternumber = input()  # I'll take the input and save it in a variable called " Enternumber"
    if Enternumber == "1":
        # if user put number "1"  He/She  would ask a group of questions to  Check the conditions

        print("  :  (CPIT-110) ماهو تقديرك في مقرر البرمجة وحل المشكلات")

        COMPUTER = input()
        if COMPUTER <= "79":
            print(" عليك  الحصول على تقدير جيد مرتفع على الأقل (٧٥) في برمجة 1 (CPCS-202) او برمجة 2 (CPCS-203)")
        else:
            print("هنيئًا لك لقت حققت الشرط الاول . ")

        print("   ماهو تقديرك في مقررفي مقرر الرياضيات (110 MATH):  ")
        MATH = input()
        if MATH <= "85":
            print("عليك الحصول على تقدير جيد مرتفع على الأقل (٧٥) في برمجة 1 (CPCS-202) او برمجة 2 (CPCS-203)")
        else:
            print("هنيئًا لك لقت حققت الشرط الثاني .")
        print("   ماهو تقديرك في مقررفي مقرر  اللغة إنجليزية (104 ELI):  ")
        ENGLISH = input()
        if ENGLISH <= "85":
            print(
                "عليك الحصول على تقدير جيد جداً (80) على الأقل في مقرر مقدمة الحوسبة(201 CPIT) (أو) مقرر أساليب الكتابة (221 CPIT) ")
        else:
            print("هنيئًا لك لقت حققت الشرط الثالث .")
        print("ادخل معدلك")
        GBR = input()
        if GBR >= "3.75":
            print("هنيئًا لك لقت حققت الشرط الرابع .")
        elif GBR <= "5.01":
            print(" مدخل خاطئ  ")
        else:
            print("عليك المحاولة في رفع المعدل")

            print('''

       ألا يزيد عدد الطلاب المحولين في كل فصل دراسي عن (15) طلاب لكل شطر.
• في حال تقدم أكثر من (15) طالب بطلب التحويل إلى الكلية (لكل شطر) فتكون المفاضلة بينهم لاختيار أفضل (15)
على أساس المعدل الموزون لآخر مقرر درسه الطالب من 
مقررات المساريين التاليين:
  • المسار الأول: الرياضيات 110 Math والبرمجة وحل المشكلات 110 CPIT (أو) برمجة 1 202 CPCS (أو) برمجة 2 203 CPCS
 • المسار الثاني: اللغة الإنجليزية 104 ELI (أو) مقدمة في الحوسبة 201 CPIT (أو) أساليب الكتابة 221 CPIT
رابط الشروط على موقع الكلية: https://computing.kau.edu.sa/pages-transferring-ar.aspx
       ''')
    elif Enternumber == "2":
        # if user put number "2" it will display all conditions

        print('''

  شروط وآلية تحويل الطلاب والطالبات من الكليات الأخرى في جامعة الملك عبد العزيز إلى كلية الحاسبات وتقنية المعلومات:￼￼￼￼￼
• أن يكون الطالب قد حصل على تقدير جيد جداً على الأقل (80) في مقرر البرمجة وحل المشكلات (110 CPIT) (أو) جيد مرتفع على الأقل (75) في مقرر برمجة 1 (202 CPCS) (أو) مقرر برمجة 2 (203 CPCS)                
• أن يكون الطالب قد حصل على تقدير جيد جداً مرتفع على الأقل (85) في مقرر الرياضيات (110 MATH) (أو) جيد مرتفع على الأقل (75) في مقرر برمجة 1 (202 CPCS) (أو) مقرر برمجة 2 (203 CPCS)                      
• أن يكون الطالب قد حصل على تقدير جيد جداً مرتفع على الأقل (85) في مقرر اللغة إنجليزية (104 ELI) (أو) جيد جداً (80) على الأقل في مقرر مقدمة الحوسبة (201 CPIT) (أو) مقرر أساليب الكتابة(221 CPIT)       
• ألا يقل معدل الطالب الترا كمي عن (3.75) عند الرغبة في تسجيل مقررات الكلية لتعويض شرط النقص في مقررات السنة التحضيرية، ولمجلس الكلية الاستثناء في هذا الشرط إذا اقتنع المجلس بالمبررات الأكاديمية للطا 
• ألا يزيد عدد الطلاب المحولين في كل فصل دراسي عن (15) طلاب لكل شطر. • في حال تقدم أكثر من (15) طالب بطلب التحويل إلى الكلية (لكل شطر) فتكون المفاضلة بينهم لاختيار أفضل (15) على أساس المعدل الموزون لآخر
مقررات المساريين التاليين:                                          
 • المسار الأول: الرياضيات 110 Math والبرمجة وحل المشكلات 110 CPIT (أو) برمجة 1 202 CPCS (أو) برمجة 2 203 CPCS 
 • المسار الثاني: اللغة الإنجليزية 104 ELI (أو) مقدمة في الحوسبة 201 CPIT (أو) أساليب                         
رابط الشروط على موقع الكلية: https://computing.kau.edu.sa/pages-transferring-ar.aspx

  ''')
    elif Enternumber == "3":
        prog2 = "0"
        prog1 = "0"
        CPIT1 = "0"
        CPIT2 = "0"
        side1="0"
        side2 = "0"
        side3 = "0"
        largest2 = "0"
        largest1 = "0"
        largest3 = "0"
        print("  :  (CPIT-110) ماهو تقديرك في مقرر البرمجة وحل المشكلات")
        computer=input()
        if computer<= "79":
            print("   ماهو تقديرك في مقرر برمجة 1 (202 CPCS) :")
            prog1=input()
            if prog1<"75":
                print("   ماهو تقديرك في مقرر برمجة 2 (203 CPCS) :")
                prog2 = input()

        if (computer >= prog1) and (computer >= prog2):
            largest1 = computer
        elif (prog1 >= computer) and (prog1 >= prog2):
            largest1 = prog1
        else:
            largest1 = prog2

        if largest1 == computer:
            side1 = (int(computer) * Hours["computer"]) / Hours["computer"]
        elif largest1 == prog1:
            side1 = (int(prog1) * Hours["prog1"]) / Hours["prog1"]
        else:
            side1 = (int(prog2) * Hours["prog2"]) / Hours["prog2"]

        print("   ماهو تقديرك في مقررفي مقرر الرياضيات (110 MATH):  ")
        math=input()
        if math < "85":
            print("   ماهو تقديرك في مقرر برمجة 1 (202 CPCS) :")
            prog1 = input()
            if prog1 < "75":
                print("   ماهو تقديرك في مقرر برمجة 2 (203 CPCS) :")
                prog2 = input()




                if (math >= prog1) and (math >= prog2):
                    largest2 = math
                elif (prog1 >= math) and (prog1 >= prog2):
                    largest2 = prog1
                else:
                    largest2 = prog2
        if largest2 == math:
            side2 = (int(math) * Hours["math"]) / Hours["math"]
        elif largest2 == prog1:
            side2 = (int(prog1) * Hours["prog1"]) / Hours["prog1"]
        else:
            side2 = (int(prog2) * Hours["prog2"]) / Hours["prog2"]

        print("   ماهو تقديرك في مقررفي مقرر  اللغة إنجليزية (104 ELI):  ")
        english=input()
        if english < "85":
            print("   ماهو تقديرك في مقرر مقدمة الحوسبة (201 CPIT) :")
            CPIT1 = input()
            if CPIT1 < "80":
                print("   ماهو تقديرك في مقرر أساليب الكتابة(221 CPIT)  :")
                CPIT2 = input()



                if (english >= CPIT1) and (english >= CPIT2):
                 largest3 = english
                elif (CPIT1 >= english) and (CPIT1 >= CPIT2):
                 largest3 = CPIT1
                else:
                  largest3 = CPIT2

                if largest2 == english:
                    side3 = (int(english) * Hours["english"]) / Hours["english"]
                elif largest2 == CPIT1:
                    side3 = (int(CPIT1) * Hours["CPIT1"]) / Hours["CPIT1"]
                else:
                    side3 = (int(CPIT2) * Hours["CPIT2"]) / Hours["CPIT2"]


# Calculate GBA
        if side1 == side2:
          GBA = float(side1) + float(side3)
        else:
         GBA = float(side1) + float(side2) + float(side3)



        print("المعدل الموزون =")
        print(GBA,"%")



#
    elif Enternumber == "4":
        # if user put number "3" Exit from the loop by use   break
        print("شكرًا جزيلًا")
        break

    else:  # this case for f he/she entered the wrong input and say that with try again

        print(" مدخل خاطئ ، حاول مره اخرى ")

